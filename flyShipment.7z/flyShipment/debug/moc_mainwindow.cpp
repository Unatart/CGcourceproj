/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[30];
    char stringdata0[399];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "info_buttons"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 5), // "about"
QT_MOC_LITERAL(4, 31, 10), // "load_model"
QT_MOC_LITERAL(5, 42, 9), // "load_ship"
QT_MOC_LITERAL(6, 52, 12), // "create_model"
QT_MOC_LITERAL(7, 65, 9), // "add_model"
QT_MOC_LITERAL(8, 75, 6), // "Model&"
QT_MOC_LITERAL(9, 82, 5), // "model"
QT_MOC_LITERAL(10, 88, 11), // "create_ship"
QT_MOC_LITERAL(11, 100, 19), // "on_clearScr_clicked"
QT_MOC_LITERAL(12, 120, 15), // "on_ship_toggled"
QT_MOC_LITERAL(13, 136, 7), // "checked"
QT_MOC_LITERAL(14, 144, 13), // "keyPressEvent"
QT_MOC_LITERAL(15, 158, 10), // "QKeyEvent*"
QT_MOC_LITERAL(16, 169, 13), // "mydrawZBuffer"
QT_MOC_LITERAL(17, 183, 18), // "on_DrawBox_toggled"
QT_MOC_LITERAL(18, 202, 22), // "on_ModelButton_clicked"
QT_MOC_LITERAL(19, 225, 21), // "on_ShipButton_clicked"
QT_MOC_LITERAL(20, 247, 18), // "on_DrawBox_clicked"
QT_MOC_LITERAL(21, 266, 16), // "updateSliderBPos"
QT_MOC_LITERAL(22, 283, 5), // "value"
QT_MOC_LITERAL(23, 289, 30), // "on_modelList_currentRowChanged"
QT_MOC_LITERAL(24, 320, 10), // "currentRow"
QT_MOC_LITERAL(25, 331, 20), // "on_modelList_clicked"
QT_MOC_LITERAL(26, 352, 5), // "index"
QT_MOC_LITERAL(27, 358, 17), // "on_models_toggled"
QT_MOC_LITERAL(28, 376, 12), // "able_to_move"
QT_MOC_LITERAL(29, 389, 9) // "new_model"

    },
    "MainWindow\0info_buttons\0\0about\0"
    "load_model\0load_ship\0create_model\0"
    "add_model\0Model&\0model\0create_ship\0"
    "on_clearScr_clicked\0on_ship_toggled\0"
    "checked\0keyPressEvent\0QKeyEvent*\0"
    "mydrawZBuffer\0on_DrawBox_toggled\0"
    "on_ModelButton_clicked\0on_ShipButton_clicked\0"
    "on_DrawBox_clicked\0updateSliderBPos\0"
    "value\0on_modelList_currentRowChanged\0"
    "currentRow\0on_modelList_clicked\0index\0"
    "on_models_toggled\0able_to_move\0new_model"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x0a /* Public */,
       3,    0,  115,    2, 0x0a /* Public */,
       4,    0,  116,    2, 0x08 /* Private */,
       5,    0,  117,    2, 0x08 /* Private */,
       6,    0,  118,    2, 0x08 /* Private */,
       7,    1,  119,    2, 0x08 /* Private */,
      10,    0,  122,    2, 0x08 /* Private */,
      11,    0,  123,    2, 0x08 /* Private */,
      12,    1,  124,    2, 0x08 /* Private */,
      14,    1,  127,    2, 0x08 /* Private */,
      16,    0,  130,    2, 0x08 /* Private */,
      17,    0,  131,    2, 0x08 /* Private */,
      18,    0,  132,    2, 0x08 /* Private */,
      19,    0,  133,    2, 0x08 /* Private */,
      20,    0,  134,    2, 0x08 /* Private */,
      21,    1,  135,    2, 0x08 /* Private */,
      23,    1,  138,    2, 0x08 /* Private */,
      25,    1,  141,    2, 0x08 /* Private */,
      27,    1,  144,    2, 0x08 /* Private */,
      28,    1,  147,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, 0x80000000 | 15,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::Int,   24,
    QMetaType::Void, QMetaType::QModelIndex,   26,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Bool, 0x80000000 | 8,   29,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->info_buttons(); break;
        case 1: _t->about(); break;
        case 2: _t->load_model(); break;
        case 3: _t->load_ship(); break;
        case 4: _t->create_model(); break;
        case 5: _t->add_model((*reinterpret_cast< Model(*)>(_a[1]))); break;
        case 6: _t->create_ship(); break;
        case 7: _t->on_clearScr_clicked(); break;
        case 8: _t->on_ship_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 10: _t->mydrawZBuffer(); break;
        case 11: _t->on_DrawBox_toggled(); break;
        case 12: _t->on_ModelButton_clicked(); break;
        case 13: _t->on_ShipButton_clicked(); break;
        case 14: _t->on_DrawBox_clicked(); break;
        case 15: _t->updateSliderBPos((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_modelList_currentRowChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_modelList_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 18: _t->on_models_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: { bool _r = _t->able_to_move((*reinterpret_cast< Model(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
